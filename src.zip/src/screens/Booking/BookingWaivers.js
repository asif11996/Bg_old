import { StyleSheet, Text, View } from "react-native";
import React from "react";

const BookingWaivers = () => {
  return (
    <View>
      <Text>BookingWaivers</Text>
    </View>
  );
};

export default BookingWaivers;

const styles = StyleSheet.create({});
