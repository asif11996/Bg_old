export const SET_SPLASH_SCREEN_VALUE = 'SET_SPLASH_SCREEN_VALUE';

export const splashScreenFalse = () => {
  return {type: SET_SPLASH_SCREEN_VALUE, isSplashScreen: false};
};
