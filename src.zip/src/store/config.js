const AppConfig = {
  apiUrl: "https://bogathon.websitesupport.ie/api/" // Replace with your actual API URL
};

export default AppConfig;
