import {StyleSheet, Text, View} from 'react-native';
import CircularProgress from 'react-native-circular-progress-indicator';

import React from 'react';

const CircularProgressItem = () => {
  return (
    <View>
      <Text>CircularProgressItem</Text>
    </View>
  );
};

export default CircularProgressItem;

const styles = StyleSheet.create({});
