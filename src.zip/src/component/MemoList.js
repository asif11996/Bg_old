import {StyleSheet, Text, View} from 'react-native';
import React from 'react';

const MemoList = () => {
  return (
    <View>
      <Text>MemoList</Text>
    </View>
  );
};

export default MemoList;

const styles = StyleSheet.create({});
